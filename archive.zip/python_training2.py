print("Hi!")
name = input("What is your name? ")

print("It's nice to meet you,", name)
answer = input("Are you enjoying the course?")

if answer== "Yes":
    print("That's good to hear!")
else: print("Oh no! that makes me sad!")